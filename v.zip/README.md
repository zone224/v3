<p align="center">
<img src="https://i.ibb.co/rp4ZnpZ/20210407-072131.jpg"/>
</p>
<p align="center">
<a href="#"><img title="akirabotv3" src="https://img.shields.io/badge/Whatsapp Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/AkiRaID"><img title="Author" src="https://img.shields.io/badge/AUTHOR-AKIRA-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/AkiRaID/followers"><img title="Followers" src="https://img.shields.io/github/followers/AkiRaID?color=blue&style=flat-square"></a>
<a href="https://github.com/AkiRaID/akirabotv3/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/AkiRaID/akirabotv3?color=red&style=flat-square"></a>
<a href="https://github.com/AkiRaID/akirabotv3/network/members"><img title="Forks" src="https://img.shields.io/github/forks/AkiRaID/akirabotv3?color=red&style=flat-square"></a>
<a href="https://github.com/AkiRaID/akirabotv3/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/AkiRaID/akirabotv3?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAkiRaID%2Fakirabotv3&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>

<p align="center">
    <img
        src="https://img.shields.io/badge/node.js%20-%2343853D.svg?&style=for-the-badge&logo=node.js&logoColor=white" />
    <img
        src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
</p>
<div align="center">
<details>
 <summary>😔 Help me!</summary>
 
 [Saweria](https://saweria.co/akirayt)
 
</details>

<p align="center">
📫 Follow Me On
</p>

<p align="center">
<a href="https://www.instagram.com/akirashopreal" target="_blank"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?&style=flat-square&logo=instagram&logoColor=white" alt="Instagram"></a>
<a href="https://m.youtube.com/channel/UCvVd-kAsrJUjg0bwKqxUPeg" target="_blank"><img src="https://img.shields.io/badge/YouTube-%231877F2.svg?&style=flat-square&logo=YouTube&logoColor=white" alt="YouTube"></a>
<a href="https://wa.me/6282158549899" target="_blank"><img src="https://img.shields.io/badge/Whatsapp-%808080.svg?&style=flat-square&logo=Whatsapp&logoColor=white" alt="Whatsapp"></a>
</p>

## Info
```bash
Akira Bot adalah Bot Whatsapp yg Memiliki 500+ Fitur, 
dan Menggunakan Bermacam² Rest Api
```

## Tools
Alat yg diperlukan

```bash
whatsapp
termux
2 Handphone
```


## Getting Started

This project require NodeJS v12

### Install
Clone this project

```bash
$ git clone https://github.com/AkiRaID/akirabotv3
$ cd akirabotv3
```

Install the dependencies:

```bash
$ pkg install nodejs
$ pkg install ffmpeg
$ pkg install imagemagick
$ bash install.sh
```

### Usage
Run the Whatsapp bot

```bash
$ node index.js
```

Scan Qrnya,dan Selamat Menikmati Bot Wanya😁


## Thanks to
* [Roy](https://github.com/Pxc7b)
* [Riu](https://github.com/Pxc7)
* [MhankBarBar](https://github.com/MhankBarBar)
* [LolHuman](https://github.com/LoL-Human)

