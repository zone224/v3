const donasi = () => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          DONASI BRO?  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱❉ *DONASI YOK* ❉⊰━━✿
┃   
┣━⊱ *DANA*
┣⊱ 085801121405
┣━⊱ *GOPAY*
┣⊱ 085801121405
┣━⊱ *PULSA*
┣⊱ 085801121405
┃
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
